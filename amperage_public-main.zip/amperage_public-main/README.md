# Amperage
PERFECT movement simulator for Minecraft

## Why error?
I don't know. please crteate  pull requeszt if you fgind reason

## Future features planned
 - Switch to Vulkan renderer for Minecraft look emulation
 - Support Proton GE
 - Add ReactOS support (broken right now)
 - Fix kernel panic on BSD
 - Add iOS suport (nonly Android )
 - Add ParrotOS support ( ban custom kenrel (very danger) )
 - Source Engine SDK support ( only use unreal right now :vomit:)
 - remove tim sweeney
 - Enable EAC support
 - sweitch from battleeye
 - apex legen
 - bypass watchdog
 - delete shader cache from git (?? how do??)
 - add macOS support
 - add windows support
   - only work on arch right now
   - aARCH LINUX!!!!u~@!-983T62Q0W874RT
 - fix dawson skidded code (he no code)
   - also fix dawson window