package me.hydro.emulator.util;

public interface Constants {

    float LAND_MOVEMENT_FACTOR_LEGACY = 1.7266137F;
    float LAND_MOVEMENT_FACTOR_MODERN = 2.2600005F;

    float UPWARDS_MOTION = 0.5F;

    double SPRINT_MULTIPLIER = 0.40000001192092896D;
    double VERTICAL_FRICTION = 0.9800166D;

    static float getMovementFactor(ProtocolVersion version) {
        return version.isOrAbove(ProtocolVersion.V1_9)
                ? LAND_MOVEMENT_FACTOR_MODERN
                : LAND_MOVEMENT_FACTOR_LEGACY;
    }

    static double getResetMotion(ProtocolVersion version) {
        return version.isOrAbove(ProtocolVersion.V1_9)
                ? 0.005D
                : 0.003D;
    }
}
