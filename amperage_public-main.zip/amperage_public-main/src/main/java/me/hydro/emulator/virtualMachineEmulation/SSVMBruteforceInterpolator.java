package me.hydro.emulator.virtualMachineEmulation;

/**
 * SSVM allows us to run JVM in JVM
 * emulate miencr
 * aft
 *
 */
public class SSVMBruteforceInterpolator {
}
