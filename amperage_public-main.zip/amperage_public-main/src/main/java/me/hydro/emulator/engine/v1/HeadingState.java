package me.hydro.emulator.engine.v1;

public enum HeadingState {

    NORMAL,
    LAVA,
    WATER
}
