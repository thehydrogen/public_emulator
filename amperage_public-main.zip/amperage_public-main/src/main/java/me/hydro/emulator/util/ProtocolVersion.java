package me.hydro.emulator.util;

public enum ProtocolVersion {

    V1_7(5, "v1_7_R3"),
    V1_7_10(6, "v1_7_R4"),
    V1_8(46, "v1_8_R1"),
    V1_8_5(47, "v1_8_R2"),
    V1_8_9(48, "v1_8_R3"),
    V1_9(108, "v1_9_R1"),
    V1_9_1(109, "v1_9_R1"),
    V1_9_2(110, "v1_9_R2"),
    V1_9_4(111, "v1_9_R2"),
    V1_10(211, "v1_10_R1"),
    V1_10_2(212, "v1_10_R1"),
    V1_11(317, "v1_11_R1"),
    V1_12(336, "v1_12_R1"),
    V1_12_1(339, "v1_12_R1"),
    V1_12_2(341, "v1_12_R1"),
    V1_13(394, "v1_13_R1"),
    V1_13_1(402, "v1_13_R2"),
    V1_13_2(405, "v1_13_R2"),
    V1_14(478, "v1_14_R1"),
    V1_14_1(481, "v1_14_R1"),
    V1_14_2(486, "v1_14_R1"),
    V1_14_3(491, "v1_14_R1"),
    V1_14_4(499, "v1_14_R1"),
    V1_15(574, "v1_15_R1"),
    V1_15_1(576, "v1_15_R1"),
    V1_15_2(579, "v1_15_R1"),
    V1_16(736, "v1_16_R1"),
    V1_16_1(737, "v1_16_R1"),
    V1_16_2(752, "v1_16_R2"),
    V1_16_3(754, "v1_16_R2"),
    V1_16_5(755, "v1_16_R3"),
    V_1_17(756, "v1_17_R1"),
    V_1_17_1(757, "v1_17_R1"),
    UNKNOWN(5, "UNKNOWN");

    private final int version;
    private final String serverVersion;

    ProtocolVersion(int version, String serverVersion) {
        this.version = version;
        this.serverVersion = serverVersion;
    }

    public int getVersion() {
        return version;
    }

    public String getServerVersion() {
        return serverVersion;
    }

    public static ProtocolVersion getVersion(int versionId) {
        for (ProtocolVersion version : values()) {
            if (version.getVersion() == versionId) return version;
        }
        return UNKNOWN;
    }

    public static ProtocolVersion getLastVersion(){
        return values()[values().length - 2];
    }

    public boolean isLegacy() {
        return this.getVersion() < ProtocolVersion.V1_8.getVersion();
    }

    public boolean isBelow(ProtocolVersion version) {
        return this.getVersion() < version.getVersion();
    }

    public boolean isOrBelow(ProtocolVersion version) {
        return this.getVersion() <= version.getVersion();
    }

    public boolean isAbove(ProtocolVersion version) {
        return this.getVersion() > version.getVersion();
    }

    public boolean isOrAbove(ProtocolVersion version) {
        return this.getVersion() >= version.getVersion();
    }
}